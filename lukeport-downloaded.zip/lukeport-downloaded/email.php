<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='UTF-8'>
	<title>Load Application Form</title>
	<style type='text/css'>

		.img-cover{
			overflow: hidden;
		}

		.img-div{
			width:170px;
			height: 170px;
			padding: 3px;
			box-sizing: border-box;
			float: left;
		}

		.img-div img{
			width: 160px;
			height: auto;
		}
	</style>
</head>
<body>

	<p><strong>First Name</strong>: </p>
	<p><strong>Last Name</strong>: </p>
	<p><strong>Email</strong>: </p>
	<p><strong>Phone</strong>: </p>
	<p><strong>BVN</strong>: </p>
	<p><strong>Salary</strong>: </p>

	
	<div class='img-cover'>
		<div class='img-div'>
			<img src=''>
		</div>
	</div>


	
</body>
</html>