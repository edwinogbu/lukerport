<div id="reason" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header site-bg">
          <h4 class="modal-title footer-modal-title text-white">Reasons to choose lukeport</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     <div class="modal-body footer-modal-bg">
       <div class="row">
        <div class="col-md-12 text-white">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p>
        </div>
         
         
       </div>
     </div>
    </div>

  </div>
</div>
<div id="terms" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header site-bg">
          <h4 class="modal-title footer-modal-title  text-white">Terms of service</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     <div class="modal-body footer-modal-bg">
       <div class="row">
        <div class="col-md-12 text-white">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p>
        </div>
         
         
       </div>
     </div>
    </div>

  </div>
</div>
<div id="privacy" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header site-bg">
          <h4 class="modal-title footer-modal-title  text-white">Privacy Policy</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     <div class="modal-body footer-modal-bg">
       <div class="row">
        <div class="col-md-12 text-white">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p><p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam natus molestias voluptas voluptatem, quis provident reiciendis rerum doloribus fugiat sint at vel sequi accusantium ab omnis rem dolorum, eius tempore.
          </p>
        </div>
         
         
       </div>
     </div>
    </div>

  </div>
</div>