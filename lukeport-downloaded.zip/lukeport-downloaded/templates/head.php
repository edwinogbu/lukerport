<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>MAKING FINANCIAL TRANSACTIONS EASY FOR RURAL AND URBAN AREAS</title>
    <link rel="short icon"  href="<?php echo URL ?>assets/img/ecash-favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo URL ?>css/bootstrap.min.css" >
    <!-- Icon -->
    <link rel="stylesheet" href="<?php echo URL ?>css/all.min.css">
    <link rel="stylesheet" href="<?php echo URL ?>assets/fonts/line-icons.css">
    <!-- Slicknav -->
    <link rel="stylesheet" href="<?php echo URL ?>css/slicknav.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="<?php echo URL ?>css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo URL ?>css/owl.theme.css">
    
    <link rel="stylesheet" href="<?php echo URL ?>css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo URL ?>css/nivo-lightbox.css">
    <!-- Animate -->
    <link rel="stylesheet" href="<?php echo URL ?>css/animate.css">
    <!-- Main Style -->
    <link rel="stylesheet" href="<?php echo URL ?>css/main.css">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="<?php echo URL ?>css/responsive.css">
    <link rel="stylesheet" href="<?php echo URL ?>css/custom.css">

  </head>