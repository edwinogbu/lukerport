<?php 
session_start();
//DEVELOPMENT
  define('URL', 'https://lukeport.com/');

//LOCALHOST
// define('URL', 'http://localhost/ambitech/');
