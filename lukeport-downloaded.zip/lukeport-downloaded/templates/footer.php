 <!-- jQuery first, then Popper.js, then Bootstrap JS -->
 <script src="<?php echo URL ?>assets/js/jquery-min.js"></script>
 <script src="<?php echo URL ?>assets/js/popper.min.js"></script>
 <script src="<?php echo URL ?>assets/js/bootstrap.min.js"></script>
 <script src="<?php echo URL ?>assets/js/owl.carousel.min.js"></script>
 <script src="<?php echo URL ?>assets/js/jquery.mixitup.js"></script>
 <script src="<?php echo URL ?>assets/js/wow.js"></script>
 <script src="<?php echo URL ?>assets/js/jquery.nav.js"></script>
 <script src="<?php echo URL ?>assets/js/scrolling-nav.js"></script>
 <script src="<?php echo URL ?>assets/js/jquery.easing.min.js"></script>
 <script src="<?php echo URL ?>assets/js/jquery.counterup.min.js"></script>
 <script src="<?php echo URL ?>assets/js/nivo-lightbox.js"></script>
 <script src="<?php echo URL ?>assets/js/jquery.magnific-popup.min.js"></script>
 <script src="<?php echo URL ?>assets/js/waypoints.min.js"></script>
 <script src="<?php echo URL ?>assets/js/jquery.slicknav.js"></script>
 <script src="<?php echo URL ?>assets/js/main.js"></script>
 <script src="<?php echo URL ?>assets/js/form-validator.min.js"></script>
 <script src="<?php echo URL ?>assets/js/contact-form-script.min.js"></script>
 <script src="<?php echo URL ?>assets/js/custom-js.js"></script>